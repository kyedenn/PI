
//Sum, basic version

#include <stdio.h>

int main(void)
{
	int x;
	int y;
	scanf("%d%d", &x, &y);
	int z = x + y;
	printf("%d\n", z);
	return 0;
}