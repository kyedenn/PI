int succ(int x)
{
  return x+1;
}

int pred(int x)
{
  return x-1;
}

int is_zero(int x)
{
  return x == 0;
}

int is_pos(int x)
{
  return x >= 0;
}
